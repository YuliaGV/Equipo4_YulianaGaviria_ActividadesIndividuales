package com.example.ejerciciosclase9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjerciciosClase9Application {

	public static void main(String[] args) {
		SpringApplication.run(EjerciciosClase9Application.class, args);
	}

}
