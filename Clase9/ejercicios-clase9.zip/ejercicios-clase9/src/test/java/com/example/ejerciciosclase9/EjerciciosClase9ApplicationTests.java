package com.example.ejerciciosclase9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciosClase9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
